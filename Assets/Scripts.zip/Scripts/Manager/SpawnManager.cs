using Photon.Pun;
using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviourPunCallbacks
{
    [SerializeField] private List<SpawnAreaManager> spawnAreaManager = new List<SpawnAreaManager>();
    [SerializeField] float distance = 3;
    [SerializeField] GameObject aiPrefab;
    [SerializeField] PlayerSpawnPos playerSpawnPos;


    public List<Vector3> _spawnPositionList = new List<Vector3>();
    private List<GameObject> aiList = new List<GameObject>(); // AI ��ü ����Ʈ
    public int _playerCount;
    public Dictionary<int, AvatarSetNumber> pvViewId = new Dictionary<int, AvatarSetNumber>();


    #region Singleton
    private static SpawnManager _instance;

    public static SpawnManager Instance
    {
        get
        {
            // �ν��Ͻ��� ������ ������ SpawnManager�� ã�� ����
            if (_instance == null)
                _instance = FindObjectOfType<SpawnManager>();

            return _instance;
        }
    }
    #endregion

    private void Start()
    {
        _playerCount = PhotonNetwork.CurrentRoom.PlayerCount;

        // ������ Ŭ���̾�Ʈ�� ����
        if (PhotonNetwork.IsMasterClient)
        {
            photonView.RPC("SetupSpawnPoints", RpcTarget.All, distance);
        }
    }

    [PunRPC]
    private void SetupSpawnPoints(float distanceEach)
    {
        if (!PhotonNetwork.IsMasterClient) return;

        _spawnPositionList.Clear();

        foreach (var teacherarea in spawnAreaManager)
        {
            var spawnPositions = teacherarea.GetSpawnPositionList(distanceEach);
            _spawnPositionList.AddRange(spawnPositions);
        }

        // �÷��̾� ������ �Ҵ� �� ����
        playerSpawnPos.PlayerSetPosition(_spawnPositionList);

        // AI ����
        foreach (var position in _spawnPositionList)
        {
            // Room Object�� ����
            GameObject aiInstance = PhotonNetwork.InstantiateRoomObject(aiPrefab.name, position, Quaternion.identity);
            aiList.Add(aiInstance); // ������ AI�� ����Ʈ�� �߰�
        }
    }

    // ������ Ŭ���̾�Ʈ ���� �� ȣ���
    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        if (PhotonNetwork.IsMasterClient)
        {
            TransferOwnershipToNewMaster();
        }
    }

    // AI�� �������� ���ο� �����Ϳ��� ����
    private void TransferOwnershipToNewMaster()
    {
        foreach (var ai in aiList)
        {
            if (ai != null)
            {
                PhotonView aiPhotonView = ai.GetComponent<PhotonView>();

                if (aiPhotonView != null && aiPhotonView.Owner != PhotonNetwork.LocalPlayer)
                {
                    aiPhotonView.TransferOwnership(PhotonNetwork.LocalPlayer);
                }
            }
        }
    }
}