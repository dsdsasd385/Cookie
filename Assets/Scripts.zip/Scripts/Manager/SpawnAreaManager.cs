using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[RequireComponent(typeof(BoxCollider))]
public class SpawnAreaManager : MonoBehaviour
{
    public int spawnCount;  // ������ ����

    private BoxCollider _collider;

    private void Awake()
    {
        _collider = GetComponent<BoxCollider>();
    }

    public List<Vector3> GetSpawnPositionList(float distance)
    {
        List<Vector3> positionList = new();
        Bounds bounds = _collider.bounds;

        int attempts = 0;  // ���� ���� ������ ī����

        for (int i = 0; i < spawnCount; i++)
        {
            Vector3 spawnPos;
            bool isValid;

            do
            {
                if (attempts > spawnCount * 10)  // ���� ���� ���� (10��� �õ� �� �ߴ�)
                {
                    return positionList;
                }

                float posX = Random.Range(bounds.min.x, bounds.max.x);
                float posZ = Random.Range(bounds.min.z, bounds.max.z);
                spawnPos = new Vector3(posX, 0.5f, posZ);

                isValid = true;

                foreach (var pos in positionList)
                {
                    if (Vector3.Distance(spawnPos, pos) < distance)
                    {
                        isValid = false;
                        break;
                    }
                }

                attempts++;  // �õ� Ƚ�� ����
            } while (!isValid);

            positionList.Add(spawnPos);
        }

        return positionList;
    }

}