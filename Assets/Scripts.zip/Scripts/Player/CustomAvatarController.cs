using Photon.Pun;
using UnityEngine;
using System.Collections;
using System;
using UnityEngine.SceneManagement;
using System.Collections.Generic; // �ڷ�ƾ ����� ���� �ʿ�

public class CustomAvatarController : MonoBehaviourPunCallbacks
{
    public bool canMove = true;           // �̵� ���� ���� (���� �߿��� false)
    public float moveSpeed = 5f;          // �ȱ� �ӵ�
    public float sprintSpeed = 8f;        // �޸��� �ӵ�
    public float rotationSpeed = 10f;
    public float cameraDistance = 4f;
    public float cameraHeight = 2f;
    public float attackDuration = 1.8f;     // ���� �ִϸ��̼� ���� �ð� (��)
    [SerializeField] private GameObject weapon;
    [SerializeField] private Canvas gameover;
    [SerializeField] private Canvas win;
    [SerializeField] private Camera _mainCamera;
    [SerializeField] private GameObject myMesh;
    [SerializeField] private BoxCollider myCollider;


    [Header("Attack")]
    [SerializeField] private AudioClip attackClip;
    [Header("Non Attack")]
    [SerializeField] private AudioClip nonAttackClip;

    [Header("Waik")]
    [SerializeField] private AudioClip walkClip;
    
    [Header("Damaged")]
    [SerializeField] private AudioClip damagedClip;
    [Header("Die")]
    [SerializeField] private AudioClip dieClip;


    private PhotonView _pv;
    private AudioSource _audioSource;
    private Animator _animator;
    private bool _isRunning;
    private bool _isAttacking;
    private bool _isWin = false;
    private float _currentYRotation = 0f;
    private bool _isDead = false;
    private int _playerConut;
    private RaycastHit hit;
    
    [Space(25)]
    
    public Vector3 boxSize = new Vector3(0.5f, 0.5f, 0.5f);   // �ڽ��� ũ��
    public Vector3 castDirection = Vector3.forward;   // ĳ��Ʈ ����
    public float castDistance = 3f;

    // ���¸� ������ enum ����
    public enum AvatarState
    {
        Idle,
        Move,
        Attack
    }
    private AvatarState currentState = AvatarState.Idle; // �⺻ ���´� Idle

    private void Awake()
    {
        _animator = GetComponent<Animator>();
        _audioSource = GetComponent<AudioSource>();
        _pv = GetComponent<PhotonView>();


        if (attackClip == null) attackClip = Resources.Load<AudioClip>("Sound/Attack");
        if (nonAttackClip == null) nonAttackClip = Resources.Load<AudioClip>("Sound/NonAttack");
        if (walkClip == null) walkClip = Resources.Load<AudioClip>("Sound/Walk");
        if (damagedClip == null) damagedClip = Resources.Load<AudioClip>("Sound/Damaged");
        if (dieClip == null) dieClip = Resources.Load<AudioClip>("Sound/Die");
        

        if (photonView.IsMine)
        {
            if (_mainCamera != null)
            {
                GameObject cameraObject = new GameObject("PlayerCamera");
                _mainCamera = cameraObject.AddComponent<Camera>();
                _mainCamera.tag = "MainCamera"; // ī�޶��� �±׸� "MainCamera"�� ����
            }
            if (_animator == null)
            {
                Debug.LogError("Animator�� �����ϴ�! �����տ� Animator�� �߰��ϼ���.", gameObject);
            }
        }
        else
        {
            _mainCamera = GetComponentInChildren<Camera>();
            if (_mainCamera != null)
            {
                _mainCamera.gameObject.SetActive(false); // �ٸ� �÷��̾��� ī�޶�� ��Ȱ��ȭ
                _animator = null;
            }
        }
    }

    private void Start()
    {
        _isDead = false;
        _isWin = false;
        if (photonView.IsMine)
        {
            _animator.SetBool("isDie", false);
        }
    }
    private void Update()
    {
        HandlePlayerController();
        if (SceneManager.GetActiveScene().name != "Map") return;

        // ���� �÷��̾��̰� ���� ���� �ʾҴٸ� �¸� ���� üũ
        if (photonView.IsMine && !_isDead)
        {
            // PhotonNetwork.CurrentRoom.PlayerCount�� 1�̸� ������ �÷��̾���
            if (SpawnManager.Instance._playerCount <= 1)
            {
                _isWin = true;
                Win();
            }
        }
    }

    private void OnDrawGizmos()
    {
        Quaternion characterRotation = transform.rotation;
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position + characterRotation * castDirection * castDistance / 2, boxSize);

        RaycastHit hit;
        if (Physics.BoxCast(transform.position, boxSize / 2, characterRotation * castDirection, out hit, characterRotation, castDistance))
        {
            Gizmos.color = Color.green;
            Gizmos.DrawSphere(hit.point, 0.2f);
        }
    }

    // �÷��̾� ���� (�ִϸ��̼� �� ���)
    private void HandlePlayerController()
    {
        if (!photonView.IsMine || _isDead) return;

        FreeCamControl();

        _isRunning = Input.GetKey(KeyCode.LeftShift);
        _animator.SetBool("isRunning", _isRunning);

        if (Input.GetMouseButtonDown(0) && !_isAttacking)
        {
            HandleAttack();
            return;
        }

        if (!_isAttacking && canMove)
        {
            HandleMovement();
        }
    }

    // �÷��̾� ���� (�̵�)
    private void HandleMovement()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 inputDirection = new Vector3(horizontal, 0f, vertical).normalized;

        if (inputDirection.magnitude >= 0.1f)
        {
            Vector3 cameraForward = _mainCamera.transform.forward;
            Vector3 cameraRight = _mainCamera.transform.right;
            cameraForward.y = 0f;
            cameraRight.y = 0f;
            cameraForward.Normalize();
            cameraRight.Normalize();
            Vector3 moveDirection = cameraForward * inputDirection.z + cameraRight * inputDirection.x;

            Quaternion targetRotation = Quaternion.LookRotation(moveDirection);
            transform.rotation = Quaternion.Lerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);

            float speed = _isRunning ? sprintSpeed : moveSpeed;

            SetState(AvatarState.Move);
            transform.Translate(moveDirection * speed * Time.deltaTime, Space.World);
        }
        else
        {
            SetState(AvatarState.Idle);
        }
    }

    // �÷��̾��� ī�޶� ����
    private void FreeCamControl()
    {
        float mouseX = Input.GetAxis("Mouse X");
        _currentYRotation += mouseX * rotationSpeed;
        Quaternion camRotation = Quaternion.Euler(0f, _currentYRotation, 0f);
        _mainCamera.transform.position = transform.position - camRotation * Vector3.forward * cameraDistance + Vector3.up * cameraHeight;
        _mainCamera.transform.LookAt(transform.position + Vector3.up * 1.5f);
    }

    #region AudioClip

    [PunRPC]
    private void AttackAudio()
    {
        _audioSource.PlayOneShot(attackClip);
    }

    [PunRPC]
    private void NonAttackAudio()
    {
        _audioSource.PlayOneShot(nonAttackClip);
    }
    [PunRPC]
    private void WalkAudio()
    {
        _audioSource.PlayOneShot(walkClip);
    }

    [PunRPC]
    private void DamagedAudio()
    {
        _audioSource.PlayOneShot(damagedClip);
    } 
                
    [PunRPC]
    private void DieAudio()
    {
        _audioSource.PlayOneShot(dieClip);
    }

    #endregion

    // �÷��̾� ���� �޼���
    private void HandleAttack()
    {
        _isAttacking = true;
        canMove = false;
        SetState(AvatarState.Attack);
        _animator.SetTrigger("Attack");

        _pv.RPC("AttackAudio", RpcTarget.All);

        StartCoroutine(WaitForAttackAnimationToEnd());
    }

    // �÷��̾� ���� �ڷ�ƾ ����
    private IEnumerator WaitForAttackAnimationToEnd()
    {
        yield return new WaitForSeconds(attackDuration);

        _isAttacking = false;
        canMove = true;

        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 inputDirection = new Vector3(horizontal, 0f, vertical);
        if (inputDirection.sqrMagnitude > 0.01f)
        {
            SetState(AvatarState.Move);
        }
        else
        {
            SetState(AvatarState.Idle);
        }
    }

    // enum(����)�� ���� �ִϸ��̼� Value����
    private void SetState(AvatarState newState)
    {
        if (_animator == null) return;

        if (currentState == newState) return;
        currentState = newState;

        switch (currentState)
        {
            case AvatarState.Idle:
                _animator.SetBool("isWalking", false);
                _animator.SetBool("isRunning", false);
                break;
            case AvatarState.Move:
                _animator.SetBool("isWalking", true);
                break;
            case AvatarState.Attack:
                _animator.SetBool("isWalking", false);
                _animator.SetBool("isRunning", false);
                break;
        }
    }

    // �¸� �޼���
    private void Win()
    {
        // _isWin�� true�̰�, ���� ���� �ʾҴٸ�
        if (_isWin && !_isDead && photonView.IsMine)
        {
            win.gameObject.SetActive(true);
            UnlockCursor();
            GameManager.Instance.isWin = true;
        }
    }

    // ��� �޼���
    public void Die()
    {
        if (myMesh == null) return;

        // �´¼Ҹ� ���
        _pv.RPC("DamagedAudio", RpcTarget.All);

        if (photonView.IsMine)
        {
            StartCoroutine(DieAnim());
            GameManager.Instance.isDie = true;
        }
    }


    // ��� �ִϸ��̼� �ڷ�ƾ
    private IEnumerator DieAnim()
    {
        _isDead = true;
        _animator.SetBool("isDie", true);
        _animator.SetTrigger("Die");

        yield return new WaitForSeconds(1.5f);

        // �״¼Ҹ� ���
        _pv.RPC("DieAudio", RpcTarget.All);

        yield return new WaitForSeconds(3.5f);

        // ��� Ŭ���̾�Ʈ���� �޽��� �ݶ��̴��� ��Ȱ��ȭ�ϵ��� RPC ȣ��
        photonView.RPC("DisableMesh", RpcTarget.All);

        photonView.RPC("DecreasePlayerCountRPC", RpcTarget.All);

        // ���� ���� UI�� ���ÿ����� ǥ�� (���ϴ� ��� ��� Ŭ���̾�Ʈ���� Ȱ��ȭ�Ϸ��� RPC ���)
        if (photonView.IsMine)
        {
            gameover.gameObject.SetActive(true);
            UnlockCursor();
        }
    }
    // ���콺 ��ݸ޼���
    public void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }


    // �÷��̾� �� üũ �޼���(Photon)
    [PunRPC]
    private void DecreasePlayerCountRPC()
    {
        SpawnManager.Instance._playerCount--;
    }

    // ����� Mesh �Ⱥ��̰��ϴ� �޼��� (Photon)
    [PunRPC]
    private void DisableMesh()
    {
        // ��� Ŭ���̾�Ʈ���� ����ǵ��� if�� ����
        myMesh.SetActive(false);
        myCollider.enabled = false;
    }

    // pvViewId�� ���� ��ġ�ϴ� �ν��Ͻ��� Die ����
    [PunRPC]
    private void LocalDie(int viewId)
    {
        Dictionary<int, AvatarSetNumber> dictionaryViewId = SpawnManager.Instance.pvViewId;
        if (dictionaryViewId.TryGetValue(viewId, out AvatarSetNumber avatar))
        {
            CustomAvatarController customAvatarController = avatar.GetComponent<CustomAvatarController>();
            customAvatarController.Die();
        }
    }

    private void DieRPC(int viewId)
    {
        if (PhotonNetwork.IsMasterClient)
        {
            photonView.RPC("LocalDie", RpcTarget.All, viewId);
        }
    }

    // Raycast�� Attack�̺�Ʈ ���� �޼���
    public void AttackEnemy()
    {
        if (Physics.BoxCast(transform.position, boxSize / 2, transform.forward * 0.5f, out hit, Quaternion.identity, castDistance))
        {
            if (hit.collider.gameObject.layer == LayerMask.NameToLayer("Player"))
            {
                var pv = hit.collider.gameObject.GetComponent<PhotonView>();
                var id = pv.ViewID;
                if (SceneManager.GetActiveScene().name == "Map")
                {
                    CustomAvatarController customAvatarController = hit.collider.gameObject.GetComponent<CustomAvatarController>();

                    if (customAvatarController._isDead == true)
                    {
                        return;
                    }
                    else
                    {
                        // ���ݼҸ� ���
                        _pv.RPC("AttackAudio", RpcTarget.All);

                        DieRPC(id);
                        Debug.Log("Player Attack");
                    }
                }
            }
            else if (hit.collider.gameObject.layer == LayerMask.NameToLayer("Ai"))
            {
                var pv = hit.collider.gameObject.GetComponent<PhotonView>();
                var id = pv.ViewID;

                AIWalker aiwalker = hit.collider.gameObject.GetComponent<AIWalker>();

                if (aiwalker == null) { return; }

                if (SceneManager.GetActiveScene().name == "Map")
                {
                    // ���ݼҸ� ���
                    _pv.RPC("AttackAudio", RpcTarget.All);
                    Debug.Log("Ai Attack");
                    aiwalker.DieRPC(id);
                }
            }

            else
            {
                // NonAttack�Ҹ� ���
                _pv.RPC("NonAttack", RpcTarget.All);
            }
        }
    }

}


