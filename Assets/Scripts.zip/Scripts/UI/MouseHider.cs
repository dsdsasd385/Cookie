using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseHider : MonoBehaviour
{

    private bool isLock = true;
    void Start()
    {
        isLock = true;
        LockCursor(); // ���� ���� �� ���콺 ���
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isLock)
            {
                UnlockCursor();
            }
            else
            {
                LockCursor();
            }
        }     
    }
    public void LockCursor()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        isLock = true;
        Debug.Log("���콺 ��ݵ�");
    }

    public void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        isLock = false;
        Debug.Log("���콺 ��� ������");
    }
}
