using UnityEngine;
using TMPro;
using Photon.Pun;
using Photon.Realtime;

public class PlayerList : MonoBehaviourPunCallbacks
{
    [SerializeField] TMP_Text text;

    private void Start()
    {
        UpdatePlayerList();
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        Debug.Log($"���ο� �÷��̾� ����: {newPlayer.NickName}");
        photonView.RPC("UpdatePlayerList", RpcTarget.All);
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        Debug.Log($"�÷��̾� ����: {otherPlayer.NickName}");
        photonView.RPC("UpdatePlayerList", RpcTarget.All);
    }

    [PunRPC]
    private void UpdatePlayerList()
    {
        text.text = $"Player : {PhotonNetwork.CurrentRoom.PlayerCount}";
    }
}
